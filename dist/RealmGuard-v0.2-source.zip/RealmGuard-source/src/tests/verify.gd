extends SceneTree

var checks = 0
var failures: Array[String] = []

func _initialize() -> void:
 call_deferred("run")

func check(condition: bool, message: String) -> void:
 checks += 1
 if not condition:
  failures.append(message)
  push_error(message)

func fresh():
 var game = load("res://main.tscn").instantiate()
 root.add_child(game)
 game.set_process(false)
 game.mode = "playing"
 game.sound_on = false
 return game

func run() -> void:
 root.size = Vector2i(1280,720)
 var game = fresh()
 await process_frame
 await process_frame
 print("INPUT_VIEWPORT ",game.get_viewport_rect()," buttons=",game.hud.buttons.size())
 # Real HUD hit rectangles and separate touch IDs exercise simultaneous input.
 var move = InputEventScreenTouch.new()
 move.index = 0
 move.position = Vector2(165,602)
 move.pressed = true
 game._input(move)
 check(game.hud.joystick.x>0,"摇杆应接收移动触点")
 var cast = InputEventScreenTouch.new()
 cast.index = 1
 cast.position = Vector2(1008,636)
 cast.pressed = true
 game._input(cast)
 check(game.cooldowns[0]>0,"第二触点应能释放旋风斩")
 check(game.hud.joy_id==0 and game.hud.joystick.x>0,"技能触点不能夺走摇杆")
 cast.pressed = false
 game._input(cast)
 check(game.hud.joystick.x>0,"松开技能触点不能停止移动")
 var before: Vector2 = game.hero
 game.simulate(.1)
 check(game.hero.x>before.x,"摇杆应实际移动英雄")
 move.pressed = false
 game._input(move)
 check(game.hud.joystick==Vector2.ZERO,"松开摇杆应停止移动")
 # Economy and one-time equipment effects.
 game.gold = 1000
 game.action("buy0")
 check(game.gold==820 and game.power==60 and game.inventory==[0],"购买应扣款并提高攻击")
 game.action("buy0")
 check(game.gold==820 and game.power==60,"重复购买不能重复扣款或叠加属性")
 game.action("buy2")
 check(game.max_hp==680 and game.hp==680,"生命装备应同步增加当前和最大生命")
 game.gold = 0
 game.action("buy5")
 check(not game.inventory.has(5),"金币不足不能购买")
 # A real enemy receives skill damage and stun; cooldown blocks repeat damage.
 game.enemies.clear()
 game.spawn_enemy(game.hero+Vector2(30,0),1)
 game.cooldowns[1] = 0.0
 game.action("skill1")
 var after_hp: float = game.enemies[0].hp
 check(after_hp<game.enemies[0].max_hp and game.enemies[0].stun>0,"雷霆应造成伤害并眩晕")
 game.action("skill1")
 check(game.enemies[0].hp==after_hp,"冷却期间不能重复造成技能伤害")
 game.points = 1
 game.action("up0")
 game.action("up0")
 check(game.skills[0]==2 and game.points==0,"技能点应只消费一次")
 game.enemies.clear()
 game.gold = 500
 game.core_hp = 900.0
 game.action("repair")
 check(game.core_hp==1300 and game.gold==400,"核心修复应恢复生命并扣款")
 var wall_result: Vector2 = game.move_actor(Vector2(700,300),Vector2(80,0))
 check(wall_result.x==700,"英雄应被围墙阻挡")
 # Challenge must suspend and then restore the exact defense units.
 game.spawn_enemy(Vector2(1100,500),0)
 var original_pos: Vector2 = game.enemies[0].pos
 game.wood = 10
 game.action("boss")
 check(game.arena and game.wood==5 and game.enemies[0].kind==3,"挑战应扣木头并进入独立区域")
 check(game.saved_enemies.size()==1,"防守怪物应保留")
 game.save_game()
 var arena_resume = fresh()
 arena_resume.load_game()
 check(arena_resume.arena and arena_resume.enemies[0].kind==3,"挑战中读档应恢复 BOSS")
 arena_resume.leave_arena()
 check(arena_resume.enemies[0].pos==original_pos,"挑战存档应保留原防守怪物")
 game.enemies[0].hp = 0.0
 game.simulate(.01)
 check(not game.arena and game.boss_wins==1,"击败 BOSS 应返回原战场")
 check(game.enemies.size()==1 and game.enemies[0].pos==original_pos,"挑战后防守怪物位置应保持")
 # Serialized encounter, cooldown, equipment and RNG resume together.
 game.gold = 333
 game.cooldowns = [1.2,3.4,5.6]
 var old_rng: int = game.rng.state
 check(game.save_game(),"保存应成功")
 var resumed = fresh()
 resumed.load_game()
 check(resumed.mode=="playing" and resumed.gold==333,"存档应恢复游戏进度")
 check(resumed.enemies.size()==1 and resumed.enemies[0].pos==original_pos,"存档应恢复战场怪物")
 check(resumed.inventory==game.inventory and resumed.power==game.power,"存档应恢复装备和属性")
 check(resumed.cooldowns==[1.2,3.4,5.6] and resumed.rng.state==old_rng,"存档应恢复冷却和随机数状态")
 resumed.simulate(.1)
 check(resumed.elapsed>game.elapsed,"读档后的游戏应能继续运行")
 # Boss warning resolves at the marked position, not the hero's later location.
 var battle = fresh()
 battle.wood = 10
 battle.action("boss")
 battle.enemies[0].special = 0.0
 battle.simulate(.01)
 var mark: Vector2 = battle.enemies[0].strike
 battle.hero += Vector2(250,0)
 var health: float = battle.hp
 battle.simulate(1.2)
 check(battle.hp>=health and battle.enemies[0].strike==mark,"离开红色预警后应避开砸地伤害")
 # Campaign bot uses normal movement, attacks, purchases and cooldowns.
 var campaign = fresh()
 campaign.action("up0")
 var ticks = 0
 while campaign.ended=="" and ticks<22000:
  if campaign.enemies.size()>0:
   var nearest = campaign.enemies[0].pos
   var distance = campaign.hero.distance_to(nearest)
   for enemy in campaign.enemies:
    var d = campaign.hero.distance_to(enemy.pos)
    if d<distance: nearest=enemy.pos; distance=d
   campaign.hud.joystick = campaign.hero.direction_to(nearest) if distance>65 else Vector2.ZERO
   if distance<135 and campaign.cooldowns[0]<=0: campaign.action("skill0")
   if distance<220 and campaign.cooldowns[1]<=0: campaign.action("skill1")
  else: campaign.hud.joystick = Vector2.ZERO
  if campaign.hp<campaign.max_hp*.6 and campaign.cooldowns[2]<=0: campaign.action("skill2")
  for index in range(6):
   if not campaign.inventory.has(index) and campaign.gold>=campaign.ITEMS[index].cost: campaign.action("buy%d" % index)
  if campaign.points>0:
   for index in range(3):
    if campaign.skills[index]<5 and campaign.points>0: campaign.action("up%d" % index)
  campaign.simulate(.1)
  ticks += 1
 check(campaign.ended=="victory" and campaign.wave_no==8,"使用正常规则应能完成八波防守")
 print("CAMPAIGN seconds=",campaign.elapsed," core=",campaign.core_hp," level=",campaign.level," end=",campaign.ended)
 for node in [game,resumed,arena_resume,battle,campaign]: node.queue_free()
 await process_frame
 print("VERIFIED ",checks," checks; failures=",failures.size())
 quit(0 if failures.is_empty() else 1)
