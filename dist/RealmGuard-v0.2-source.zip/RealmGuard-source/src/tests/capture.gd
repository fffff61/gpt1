extends SceneTree

func _initialize() -> void:
 call_deferred("capture")

func capture() -> void:
 var directory = ProjectSettings.globalize_path("user://captures")
 for argument in OS.get_cmdline_user_args():
  if argument.begins_with("--capture-dir="): directory = argument.trim_prefix("--capture-dir=")
 var status = DirAccess.make_dir_recursive_absolute(directory)
 if status!=OK:
  push_error("Cannot create capture directory")
  quit(1)
  return
 root.size = Vector2i(1280,720)
 var game = load("res://main.tscn").instantiate()
 root.add_child(game)
 game.set_process(false)
 game.wave_no = 3
 game.gold = 460
 game.wood = 8
 game.hero = Vector2(1104,1010)
 for i in range(24):
  game.spawn_enemy(Vector2(1104+game.rng.randf_range(-130,130),game.rng.randf_range(780,1050)),i%3)
 for shot in [{"name":"gameplay","mode":"playing","modal":""},{"name":"shop","mode":"playing","modal":"shop"},{"name":"title","mode":"title","modal":""}]:
  game.mode = shot.mode
  game.modal = shot.modal
  game._process(0)
  await process_frame
  await process_frame
  await RenderingServer.frame_post_draw
  root.get_texture().get_image().save_png(directory.path_join(shot.name+".png"))
 print("CAPTURE_OK ",directory)
 quit()
