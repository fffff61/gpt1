extends SceneTree

func _initialize() -> void:
 call_deferred("run")

func run() -> void:
 root.size = Vector2i(1280,720)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 current_scene = scene
 await process_frame
 await process_frame
 scene.hud.pointer(Vector2(200,453),0,true)
 await process_frame
 await process_frame
 assert(current_scene.mode=="playing","开始按钮应建立新的一局")
 assert(current_scene.wave_no==0 and current_scene.gold==120,"新的一局应从初始状态开始")
 var config = ConfigFile.new()
 assert(config.load("user://campaign.cfg")==OK,"新的一局应立即保存")
 assert(config.get_value("campaign","state").gold==120,"初始存档应覆盖旧进度")
 print("RESTART_OK")
 quit()
