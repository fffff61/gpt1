extends Node2D

const WorldView = preload("res://world.gd")
const GameHUD = preload("res://hud.gd")
const SAVE_PATH = "user://campaign.cfg"
const CORE_POS = Vector2(1104, 1344)
const START_POS = Vector2(1104, 1150)
const ITEMS = [
 {"name":"霜钢长剑", "cost":180, "desc":"攻击 +18", "stat":"power", "value":18},
 {"name":"守誓之盾", "cost":160, "desc":"减伤 +12%", "stat":"armor", "value":0.12},
 {"name":"赤晶护符", "cost":200, "desc":"生命 +160", "stat":"max_hp", "value":160},
 {"name":"疾行战靴", "cost":140, "desc":"移速 +35", "stat":"speed", "value":35},
 {"name":"复苏指环", "cost":220, "desc":"每秒回复 5", "stat":"regen", "value":5},
 {"name":"秘法之书", "cost":240, "desc":"技能伤害 +35%", "stat":"spell", "value":0.35}
]

var hero = START_POS
var hp = 520.0
var max_hp = 520.0
var power = 42.0
var armor = 0.0
var speed = 220.0
var regen = 1.5
var spell = 1.0
var level = 1
var xp = 0
var gold = 120
var wood = 0
var points = 1
var skills = [1, 1, 1]
var inventory: Array[int] = []
var core_hp = 1600.0
var wave_no = 0
var pending = 0
var spawn_clock = 0.0
var intermission = 12.0
var enemies: Array[Dictionary] = []
var effects: Array[Dictionary] = []
var floating: Array[Dictionary] = []
var cooldowns = [0.0, 0.0, 0.0]
var attack_clock = 0.0
var attack_flash = 0.0
var hurt_flash = 0.0
var facing = 0
var moving = false
var auto_attack = true
var elapsed = 0.0
var autosave_clock = 0.0
var arena = false
var boss_wins = 0
var return_pos = START_POS
var saved_enemies: Array[Dictionary] = []
var ended = ""
var mode = "title"
var modal = ""
var toast = ""
var toast_time = 0.0
var sound_on = true
var rng = RandomNumberGenerator.new()
var navigation = AStarGrid2D.new()
var obstacles: Array[Rect2] = [Rect2(736,224,64,192),Rect2(736,576,64,352),Rect2(1440,224,64,192),Rect2(1440,576,64,352),Rect2(1400,1160,130,100),Rect2(620,1160,130,100)]
var world: Node2D
var hud: Control
var sounds: Dictionary = {}
var boot_args = OS.get_cmdline_user_args()

func _ready() -> void:
 rng.seed = 20261029
 navigation.region = Rect2i(0,0,69,54)
 navigation.cell_size = Vector2(32,32)
 navigation.offset = Vector2(16,16)
 navigation.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
 navigation.update()
 for box in obstacles:
  for y in range(int(box.position.y/32)-1, int(box.end.y/32)+1):
   for x in range(int(box.position.x/32)-1, int(box.end.x/32)+1):
    navigation.set_point_solid(Vector2i(x,y))
 world = WorldView.new()
 world.game = self
 add_child(world)
 var canvas = CanvasLayer.new()
 add_child(canvas)
 hud = GameHUD.new()
 hud.game = self
 canvas.add_child(hud)
 for name in ["hit","skill","coin","warn"]:
  var player = AudioStreamPlayer.new()
  player.stream = load("res://assets/%s.wav" % name)
  player.volume_db = -11
  add_child(player)
  sounds[name] = player
 if mode=="playing": save_game()
 if "--preview" in boot_args:
  mode = "playing"
  wave_no = 3
  intermission = 0
  gold = 460
  wood = 8
  for i in range(25):
   spawn_enemy(Vector2(1000+rng.randf_range(-150,180),790+rng.randf_range(-130,170)),i%3)
  hero = Vector2(1104,990)
  pending = 12
 if "--smoke" in boot_args:
  mode = "playing"
  intermission = 0.1

func _notification(what: int) -> void:
 if what in [NOTIFICATION_APPLICATION_PAUSED,NOTIFICATION_APPLICATION_FOCUS_OUT] and mode == "playing":
  save_game()
  modal = "pause"
  hud.reset_touch()
 if what == NOTIFICATION_WM_GO_BACK_REQUEST:
  if mode == "playing":
   modal = "pause" if modal == "" else ""
   hud.reset_touch()

func _input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  hud.pointer(event.position,event.index,event.pressed)
 elif event is InputEventScreenDrag:
  hud.drag(event.position,event.index)
 elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
  hud.pointer(event.position,-10,event.pressed)
 elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
  hud.drag(event.position,-10)
 elif event is InputEventKey and event.pressed and not event.echo:
  match event.physical_keycode:
   KEY_1: action("skill0")
   KEY_2: action("skill1")
   KEY_3: action("skill2")
   KEY_SPACE: action("attack")
   KEY_TAB: action("shop")
   KEY_ESCAPE: action("pause")
   KEY_F5: action("save")

func _process(dt: float) -> void:
 var screen = get_viewport_rect().size
 world.scale = Vector2.ONE*1.45
 world.position = screen*Vector2(0.5,0.48)-hero*1.45
 toast_time = maxf(0,toast_time-dt)
 for i in range(effects.size()-1,-1,-1):
  effects[i].life -= dt
  if effects[i].life <= 0: effects.remove_at(i)
 for i in range(floating.size()-1,-1,-1):
  floating[i].life -= dt
  floating[i].pos.y -= dt*30
  if floating[i].life <= 0: floating.remove_at(i)
 if mode == "playing" and modal == "" and ended == "":
  simulate(dt)
 world.queue_redraw()
 hud.queue_redraw()
 if "--smoke" in boot_args and elapsed > 5.0:
  print("SMOKE_OK wave=",wave_no," enemies=",enemies.size()," hero=",hp)
  get_tree().quit()

func simulate(dt: float) -> void:
 elapsed += dt
 autosave_clock += dt
 if autosave_clock > 20:
  autosave_clock = 0
  save_game()
 for i in range(3): cooldowns[i] = maxf(0,cooldowns[i]-dt)
 attack_clock = maxf(0,attack_clock-dt)
 attack_flash = maxf(0,attack_flash-dt)
 hurt_flash = maxf(0,hurt_flash-dt)
 hp = minf(max_hp,hp+regen*dt)
 var direction: Vector2 = hud.joystick
 direction += Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
 direction = direction.limit_length()
 moving = direction.length_squared()>0.01
 if moving:
  hero = move_actor(hero,direction*speed*dt)
  if absf(direction.x)>absf(direction.y): facing = 1 if direction.x<0 else 2
  else: facing = 3 if direction.y<0 else 0
 if not arena:
  if pending == 0 and enemies.is_empty():
   if wave_no == 8:
    ended = "victory"
    save_game()
   else:
    intermission -= dt
    if intermission <= 0:
     wave_no += 1
     pending = 12+wave_no*5
     notify_player("第 %d 波来袭 · 守护神域之心" % wave_no)
     play_sound("warn")
  if pending > 0:
   spawn_clock -= dt
   if spawn_clock <= 0:
    spawn_clock = maxf(0.23,0.65-wave_no*0.04)
    pending -= 1
    spawn_enemy(Vector2(1104+rng.randf_range(-115,115),210),rng.randi_range(0,mini(2,wave_no-1)))
 var target_index = -1
 var closest = 100.0
 for i in range(enemies.size()):
  var distance = hero.distance_to(enemies[i].pos)
  if distance<closest:
   closest = distance
   target_index = i
 if auto_attack and attack_clock == 0 and target_index >= 0:
  attack_clock = maxf(0.25,0.72-level*0.015)
  attack_flash = 0.22
  var target: Vector2 = enemies[target_index].pos
  if absf(target.x-hero.x)>absf(target.y-hero.y): facing = 1 if target.x<hero.x else 2
  else: facing = 3 if target.y<hero.y else 0
  damage_enemy(target_index,power)
  effects.append({"kind":"slash","pos":hero,"end":target,"life":0.22,"total":0.22,"radius":75.0})
  play_sound("hit")
 # Enemy state belongs to this simulation; external data is validated only at load_game.
 for i in range(enemies.size()-1,-1,-1):
  var enemy: Dictionary = enemies[i]
  enemy.cool = maxf(0,enemy.cool-dt)
  enemy.stun = maxf(0,enemy.stun-dt)
  enemy.hit = maxf(0,enemy.hit-dt)
  if enemy.hp<=0 or enemy.stun>0: continue
  var target = hero if arena or enemy.pos.distance_to(hero)<300 else CORE_POS
  var reach = 54.0 if enemy.kind!=3 else 88.0
  if enemy.kind == 3:
   enemy.special -= dt
   if enemy.special<=0:
    enemy.special = 5.5
    enemy.warning = 1.1
    enemy.strike = hero
    effects.append({"kind":"warning","pos":hero,"life":1.1,"total":1.1,"radius":125.0})
    play_sound("warn")
   if enemy.warning>0:
    enemy.warning -= dt
    if enemy.warning<=0:
     effects.append({"kind":"slam","pos":enemy.strike,"life":0.5,"total":0.5,"radius":125.0})
     if hero.distance_to(enemy.strike)<125:
      hurt_hero(135+boss_wins*30)
    continue
  if enemy.pos.distance_to(target)>reach:
   var direction_to_target: Vector2
   if arena:
    direction_to_target = enemy.pos.direction_to(target)
   else:
    enemy.repath -= dt
    if enemy.repath<=0:
     enemy.repath = rng.randf_range(0.6,1.1)
     var source_cell = Vector2i(enemy.pos/32)
     var target_cell = Vector2i(target/32)
     enemy.path = navigation.get_point_path(source_cell,target_cell)
     enemy.path_i = 1
    var path: PackedVector2Array = enemy.path
    if enemy.path_i<path.size():
     var point: Vector2 = path[enemy.path_i]
     if enemy.pos.distance_to(point)<18: enemy.path_i += 1
     direction_to_target = enemy.pos.direction_to(point)
    else: direction_to_target = enemy.pos.direction_to(target)
   var steering = direction_to_target
   for other in enemies:
    var offset: Vector2 = enemy.pos-other.pos
    var separation = maxf(0,24-offset.length())/24.0
    steering += offset.limit_length(1.0)*separation*0.8
   enemy.pos = move_actor(enemy.pos,steering.limit_length()*enemy.speed*dt)
   enemy.facing = (1 if direction_to_target.x<0 else 2) if absf(direction_to_target.x)>absf(direction_to_target.y) else (3 if direction_to_target.y<0 else 0)
  elif enemy.cool == 0:
   enemy.cool = 1.1 if enemy.kind!=3 else 1.4
   if target == CORE_POS:
    core_hp = maxf(0,core_hp-enemy.damage)
    if core_hp<=0:
     ended = "defeat"
     save_game()
   else: hurt_hero(enemy.damage)
 # Resolve deaths after all damage sources so reverse traversal remains stable.
 for i in range(enemies.size()-1,-1,-1):
  var enemy = enemies[i]
  if enemy.hp>0: continue
  var reward = 12+wave_no*2
  gold += reward if enemy.kind!=3 else 350+boss_wins*100
  xp += 12 if enemy.kind!=3 else 140
  if enemy.kind==1 or enemy.kind==3: wood += 1 if enemy.kind!=3 else 10
  floating.append({"pos":enemy.pos,"text":"+%d" % reward if enemy.kind!=3 else "+350","color":Color("e8c773"),"life":0.8})
  effects.append({"kind":"death","pos":enemy.pos,"life":0.35,"total":0.35,"radius":22.0})
  var was_boss: bool = enemy.kind==3
  enemies.remove_at(i)
  if was_boss:
   boss_wins += 1
   notify_player("挑战成功！获得金币、木头与大量经验")
   leave_arena()
   break
 while xp>=level*55:
  xp -= level*55
  level += 1
  points += 1
  max_hp += 35
  hp = minf(max_hp,hp+160)
  power += 5
  notify_player("升至 %d 级 · 获得技能点" % level)
  effects.append({"kind":"heal","pos":hero,"life":0.7,"total":0.7,"radius":85.0})
 if pending==0 and enemies.is_empty() and intermission<=0:
  intermission = 12
  gold += 50
  wood += 2

func move_actor(origin: Vector2, motion: Vector2) -> Vector2:
 var result = origin+motion
 var bounds = Rect2(310,245,1555,1160) if arena else Rect2(90,100,2010,1510)
 result.x = clampf(result.x,bounds.position.x,bounds.end.x)
 result.y = clampf(result.y,bounds.position.y,bounds.end.y)
 if not arena and navigation.is_point_solid(Vector2i(result/32)):
  if not navigation.is_point_solid(Vector2i(Vector2(result.x,origin.y)/32)): result.y = origin.y
  elif not navigation.is_point_solid(Vector2i(Vector2(origin.x,result.y)/32)): result.x = origin.x
  else: result = origin
 return result

func spawn_enemy(pos: Vector2, kind: int) -> void:
 var health = (65+wave_no*22)*[1.0,1.65,0.8,1.0][kind]
 if kind==3: health = 1450+boss_wins*650
 enemies.append({"pos":pos,"kind":kind,"hp":float(health),"max_hp":float(health),"speed":[74.0,57.0,103.0,90.0][kind]+wave_no*2,"damage":float(9+wave_no*3) if kind!=3 else 48.0+boss_wins*12,"cool":0.6,"stun":0.0,"hit":0.0,"facing":0,"repath":0.0,"path":PackedVector2Array(),"path_i":0,"special":3.0,"warning":0.0,"strike":pos})

func damage_enemy(index: int, amount: float) -> void:
 enemies[index].hp -= amount
 enemies[index].hit = 0.12
 floating.append({"pos":enemies[index].pos-Vector2(0,45),"text":str(int(amount)),"color":Color("f1ddae"),"life":0.65})

func hurt_hero(amount: float) -> void:
 var damage = amount*(1.0-armor)
 hp -= damage
 hurt_flash = 0.15
 floating.append({"pos":hero-Vector2(0,52),"text":"-%d" % damage,"color":Color("e98d80"),"life":0.65})
 if hp<=0:
  if arena: leave_arena()
  hero = START_POS
  hp = max_hp
  gold = maxi(0,gold-60)
  notify_player("在神域之心复苏 · 损失 60 金币")
  effects.append({"kind":"heal","pos":hero,"life":0.8,"total":0.8,"radius":85.0})

func action(id: String) -> void:
 match id:
  "new":
   get_tree().set_meta("start_new",true)
   get_tree().reload_current_scene()
  "continue": load_game()
  "begin": mode = "playing"
  "shop", "upgrade", "travel", "pause":
   if mode == "playing" and ended=="":
    modal = "" if modal==id else id
    hud.reset_touch()
  "close": modal = ""
  "save":
   if mode=="playing":
    if save_game(): notify_player("进度已保存到本机")
  "sound": sound_on = not sound_on; AudioServer.set_bus_mute(0,not sound_on)
  "attack": auto_attack = not auto_attack
  "repair":
   if gold<100: notify_player("修复核心需要 100 金币")
   elif core_hp>=1600: notify_player("神域之心生命已满")
   else:
    gold -= 100
    core_hp = minf(1600,core_hp+400)
    notify_player("核心恢复 400 生命")
  "boss":
   if arena: notify_player("当前已在挑战区")
   elif wood<5: notify_player("挑战需要 5 木头 · 击败重甲怪或完成波次获得")
   else:
    wood -= 5
    saved_enemies = enemies.duplicate(true)
    enemies.clear()
    return_pos = hero
    arena = true
    hero = Vector2(1104,1120)
    spawn_enemy(Vector2(1104,700),3)
    modal = ""
    notify_player("铁角守卫 · 注意躲开地面的红色预警")
  "return":
   if arena: leave_arena(); modal = ""
  _:
   if id.begins_with("skill"):
    if mode!="playing" or modal!="" or ended!="": return
    var index = int(id.right(1))
    if cooldowns[index]>0:
     notify_player("技能冷却中")
     return
    play_sound("skill")
    match index:
     0:
      cooldowns[0] = 5.0
      effects.append({"kind":"cleave","pos":hero,"life":0.45,"total":0.45,"radius":145.0})
      for i in range(enemies.size()):
       if hero.distance_to(enemies[i].pos)<145: damage_enemy(i,(80+skills[0]*35)*spell)
     1:
      cooldowns[1] = 10.0
      effects.append({"kind":"storm","pos":hero,"life":0.7,"total":0.7,"radius":235.0})
      for i in range(enemies.size()):
       if hero.distance_to(enemies[i].pos)<235:
        damage_enemy(i,(100+skills[1]*45)*spell)
        enemies[i].stun = 1.8
     2:
      cooldowns[2] = 16.0
      hp = minf(max_hp,hp+130+skills[2]*75)
      effects.append({"kind":"heal","pos":hero,"life":0.7,"total":0.7,"radius":90.0})
   elif id.begins_with("buy"):
    var index = int(id.right(1))
    var item: Dictionary = ITEMS[index]
    if inventory.has(index): notify_player("已装备此物品")
    elif gold<item.cost: notify_player("金币不足")
    else:
     gold -= item.cost
     inventory.append(index)
     set(item.stat,get(item.stat)+item.value)
     if index==2: hp += 160
     play_sound("coin")
     notify_player("已装备 · "+item.name)
   elif id.begins_with("up"):
    var index = int(id.right(1))
    if points==0: notify_player("升级英雄获得技能点")
    elif skills[index]>=5: notify_player("技能已满级")
    else:
     points -= 1
     skills[index] += 1
     notify_player("技能提升至 %d 级" % skills[index])

func leave_arena() -> void:
 arena = false
 enemies = saved_enemies
 saved_enemies = []
 hero = return_pos

func notify_player(message: String) -> void:
 toast = message
 toast_time = 3.0

func save_game() -> bool:
 var data = {"version":1,"auto_attack":auto_attack,"attack_clock":attack_clock,"facing":facing,"hero":hero,"hp":hp,"max_hp":max_hp,"power":power,"armor":armor,"speed":speed,"regen":regen,"spell":spell,"level":level,"xp":xp,"gold":gold,"wood":wood,"points":points,"skills":skills,"inventory":inventory,"core_hp":core_hp,"wave_no":wave_no,"pending":pending,"spawn_clock":spawn_clock,"intermission":intermission,"enemies":enemies,"cooldowns":cooldowns,"elapsed":elapsed,"arena":arena,"boss_wins":boss_wins,"return_pos":return_pos,"saved_enemies":saved_enemies,"ended":ended,"sound_on":sound_on,"rng_state":rng.state}
 var config = ConfigFile.new()
 config.set_value("campaign","state",data)
 var result = config.save(SAVE_PATH)
 if result!=OK:
  notify_player("保存失败，请检查应用存储空间")
  return false
 return true

func load_game() -> void:
 # Save-file boundary: validate the complete external structure once, then trust it internally.
 var config = ConfigFile.new()
 var status = config.load(SAVE_PATH)
 if status!=OK:
  notify_player("尚无可读取的本地存档")
  return
 var data: Variant = config.get_value("campaign","state")
 var valid = data is Dictionary
 if valid:
  var expected = {"version":TYPE_INT,"auto_attack":TYPE_BOOL,"attack_clock":TYPE_FLOAT,"facing":TYPE_INT,"hero":TYPE_VECTOR2,"hp":TYPE_FLOAT,"max_hp":TYPE_FLOAT,"power":TYPE_FLOAT,"armor":TYPE_FLOAT,"speed":TYPE_FLOAT,"regen":TYPE_FLOAT,"spell":TYPE_FLOAT,"level":TYPE_INT,"xp":TYPE_INT,"gold":TYPE_INT,"wood":TYPE_INT,"points":TYPE_INT,"skills":TYPE_ARRAY,"inventory":TYPE_ARRAY,"core_hp":TYPE_FLOAT,"wave_no":TYPE_INT,"pending":TYPE_INT,"spawn_clock":TYPE_FLOAT,"intermission":TYPE_FLOAT,"enemies":TYPE_ARRAY,"cooldowns":TYPE_ARRAY,"elapsed":TYPE_FLOAT,"arena":TYPE_BOOL,"boss_wins":TYPE_INT,"return_pos":TYPE_VECTOR2,"saved_enemies":TYPE_ARRAY,"ended":TYPE_STRING,"sound_on":TYPE_BOOL,"rng_state":TYPE_INT}
  valid = data.size()==expected.size()
  for key in expected:
   if not data.has(key) or typeof(data[key])!=expected[key]: valid=false; break
 if valid:
  valid = data.version==1 and data.skills.size()==3 and data.cooldowns.size()==3 and data.inventory.size()<=6 and data.wave_no>=0 and data.wave_no<=8 and data.max_hp>0 and data.level>=1 and data.ended in ["","victory","defeat"]
 if valid:
  for value in data.skills:
   if not value is int or value<1 or value>5: valid=false; break
  for value in data.cooldowns:
   if not (value is float or value is int) or value<0: valid=false; break
  for value in data.inventory:
   if not value is int or value<0 or value>=ITEMS.size(): valid=false; break
 if valid:
  for enemy in data.enemies+data.saved_enemies:
   if not enemy is Dictionary: valid=false; break
   var schema = {"pos":TYPE_VECTOR2,"kind":TYPE_INT,"hp":TYPE_FLOAT,"max_hp":TYPE_FLOAT,"speed":TYPE_FLOAT,"damage":TYPE_FLOAT,"cool":TYPE_FLOAT,"stun":TYPE_FLOAT,"hit":TYPE_FLOAT,"facing":TYPE_INT,"repath":TYPE_FLOAT,"path":TYPE_PACKED_VECTOR2_ARRAY,"path_i":TYPE_INT,"special":TYPE_FLOAT,"warning":TYPE_FLOAT,"strike":TYPE_VECTOR2}
   for key in schema:
    if not enemy.has(key) or typeof(enemy[key])!=schema[key]: valid=false; break
   if not valid: break
   if enemy.kind<0 or enemy.kind>3 or enemy.max_hp<=0: valid=false; break
 if not valid:
  notify_player("存档内容或版本不匹配，未载入")
  return
 for key in data:
  if key not in ["version","rng_state"]: set(key,data[key])
 rng.state = data.rng_state
 AudioServer.set_bus_mute(0,not sound_on)
 mode = "playing"
 modal = ""
 hud.reset_touch()
 notify_player("已恢复本地进度")

func play_sound(name: String) -> void:
 if sound_on: sounds[name].play()
