extends Control

var game: Node2D
var font = preload("res://assets/chinese.otf")
var icons = preload("res://assets/props_hd.png")
var hero_atlas = preload("res://assets/hero_hd.png")
var enemy_atlas = preload("res://assets/enemies_hd.png")
var art: Dictionary
var buttons: Array[Dictionary] = []
var joystick = Vector2.ZERO
var joy_id = -999
var joy_origin = Vector2.ZERO
var ink = Color("0f2027")
var gold = Color("cfb47c")
var pale = Color("e1dfc9")
var muted = Color("8da79f")

func _ready() -> void:
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
 art = game.world.layout
 if get_tree().has_meta("start_new"):
  get_tree().remove_meta("start_new")
  game.mode = "playing"

func _draw() -> void:
 buttons.clear()
 var s = get_viewport_rect().size
 if game.mode=="title":
  draw_rect(Rect2(Vector2.ZERO,s),Color(.025,.055,.065,.82))
  text(Vector2(90,104),"REALM GUARD  /  OFFLINE CAMPAIGN",16,gold)
  text(Vector2(86,185),"神域守卫",62,pale)
  text(Vector2(90,235),"像 素 防 线",26,Color("7fc3b5"))
  draw_line(Vector2(90,266),Vector2(565,266),Color("6a6a50"),1)
  text(Vector2(90,310),"守住最后的神域之心。",24,pale)
  text(Vector2(90,350),"在怪潮中成长，打造装备，挑战铁角守卫。",18,muted)
  text(Vector2(90,383),"8 波防守 · 三种技能 · 六格装备 · 本地存档",17,muted)
  button(Rect2(90,425,270,62),"开始新的守卫","new",true)
  button(Rect2(90,503,270,54),"继续本地进度","continue")
  text(Vector2(90,s.y-64),"单人离线战役 v0.2  ·  国风精绘素材",15,muted)
  text(Vector2(90,s.y-36),"根据参考录像重建玩法，数值为本版设计。",14,muted)
  panel(Rect2(s.x-440,120,340,440),true)
  var r: Array = art.hero_hd[0].rect
  var hero_size = Vector2(r[2],r[3])*(278.0/r[3])
  draw_circle(Vector2(s.x-270,288),126,Color(.38,.7,.61,.045))
  draw_arc(Vector2(s.x-270,288),130,0,TAU,96,Color(.72,.65,.43,.22),1)
  draw_texture_rect_region(hero_atlas,Rect2(Vector2(s.x-270-hero_size.x*.5,136),hero_size),Rect2(r[0],r[1],r[2],r[3]))
  text(Vector2(s.x-270,448),"守誓者",27,pale,true)
  text(Vector2(s.x-270,485),"你与防线，共同成长。",17,muted,true)
  text(Vector2(s.x-270,530),"横屏 · 触控 · 无需联网",15,gold,true)
  draw_toast(s)
  return
 # Top resource ribbon.
 draw_rect(Rect2(0,0,s.x,64),Color("0b1b22"))
 draw_line(Vector2(0,63),Vector2(s.x,63),Color("6c7156"),1)
 text(Vector2(22,40),"神域守卫",25,pale)
 text(Vector2(160,39),"像素防线",15,muted)
 text(Vector2(290,39),"金币",15,gold)
 text(Vector2(334,40),str(game.gold),22,pale)
 text(Vector2(432,39),"木头",15,Color("80bda5"))
 text(Vector2(476,40),str(game.wood),22,pale)
 text(Vector2(s.x*.58,39),"BOSS 挑战中" if game.arena else "第 %02d / 08 波" % game.wave_no,21,gold,true)
 button(Rect2(s.x-220,13,90,37),"存档","save")
 button(Rect2(s.x-116,13,96,37),"暂停","pause")
 # Minimap.
 var map = Rect2(22,88,166,150)
 panel(Rect2(16,80,178,199))
 text(Vector2(30,103),"战场总览",14,gold)
 var inner = Rect2(29,116,152,119)
 draw_rect(inner,Color("233d33"))
 var origin = inner.position
 draw_rect(Rect2(origin+Vector2(68,0),Vector2(17,119)),Color("8b8e72"))
 draw_rect(Rect2(origin+Vector2(20,84),Vector2(112,15)),Color("7a826a"))
 for x in [51,101]:
  for y in [20,47]: draw_rect(Rect2(origin+Vector2(x,y),Vector2(5,20)),Color("adad8b"))
 if not game.arena:
  draw_circle(origin+game.CORE_POS/Vector2(2208,1728)*inner.size,4,Color("8ae1c7"))
  for enemy in game.enemies:
   draw_rect(Rect2(origin+enemy.pos/Vector2(2208,1728)*inner.size,Vector2(2,2)),Color("e58970"))
 draw_circle(origin+game.hero/Vector2(2208,1728)*inner.size,3,Color("ffdf8a"))
 text(Vector2(29,261),"挑战区" if game.arena else "北方来敌 · 南方核心",12,muted)
 # Hero status and six-slot inventory.
 panel(Rect2(16,292,178,114))
 text(Vector2(29,320),"守誓者",19,pale)
 text(Vector2(171,319),"Lv.%d" % game.level,16,gold,true)
 bar(Rect2(29,335,151,9),game.hp/game.max_hp,Color("63bba6"))
 text(Vector2(29,365),"生命 %d / %d" % [game.hp,game.max_hp],14,pale)
 bar(Rect2(29,376,151,4),float(game.xp)/(game.level*55),Color("cbb274"))
 text(Vector2(29,398),"攻击 %d   减伤 %d%%" % [game.power,game.armor*100],12,muted)
 panel(Rect2(s.x-180,84,164,145))
 text(Vector2(s.x-166,106),"六格装备",14,gold)
 for i in range(6):
  var r = Rect2(s.x-166+(i%3)*46,118+int(i/3)*47,40,40)
  draw_rect(r,Color("162a31"))
  draw_rect(r,Color("4f625b"),false,1)
  if i<game.inventory.size(): icon(r.grow(-3),game.inventory[i])
 button(Rect2(s.x-180,245,164,44),"军需商店","shop")
 button(Rect2(s.x-180,300,164,44),"技能升级  +%d" % game.points,"upgrade",game.points>0)
 button(Rect2(s.x-180,355,164,44),"传送 / 挑战","travel")
 # Objective ribbon.
 panel(Rect2(s.x*.5-182,78,364,55))
 var status = "击败守卫后自动返回防线" if game.arena else ("下一波将在 %d 秒后到达" % ceili(game.intermission) if game.pending==0 and game.enemies.is_empty() else "剩余来敌 %d  ·  守住神域之心" % (game.pending+game.enemies.size()))
 text(Vector2(s.x*.5,101),status,15,pale,true)
 if not game.arena:
  bar(Rect2(s.x*.5-162,112,324,5),game.core_hp/1600,Color("70bba7"))
 else:
  for enemy in game.enemies:
   if enemy.kind==3: bar(Rect2(s.x*.5-162,112,324,5),enemy.hp/enemy.max_hp,Color("d38674"))
 # A translucent footer keeps controls readable over the terrain.
 draw_rect(Rect2(0,s.y-86,s.x,86),Color(.025,.065,.075,.48))
 # Virtual joystick with independent pointer ownership.
 var center = Vector2(125,s.y-118)
 draw_circle(center,72,Color(.04,.09,.11,.73))
 draw_arc(center,71,0,TAU,64,Color("657e70"),2)
 draw_arc(center,55,0,TAU,48,Color(.55,.65,.57,.2),1)
 draw_line(center-Vector2(40,0),center+Vector2(40,0),Color(.6,.7,.6,.16),1)
 draw_line(center-Vector2(0,40),center+Vector2(0,40),Color(.6,.7,.6,.16),1)
 draw_circle(center+joystick*43,26,Color("35554f"))
 draw_arc(center+joystick*43,25,0,TAU,32,Color("abc0a0"),2)
 text(Vector2(125,s.y-25),"移动",14,muted,true)
 # Abilities form an arc around the attack control.
 var centers = [Vector2(s.x-272,s.y-84),Vector2(s.x-234,s.y-199),Vector2(s.x-113,s.y-257)]
 var names = ["旋风斩","雷霆震击","复苏之光"]
 for i in range(3):
  var c: Vector2 = centers[i]
  draw_circle(c,39,Color("142c32"))
  draw_arc(c,38,0,TAU,48,Color("8aa597") if game.cooldowns[i]<=0 else Color("4e655f"),2)
  icon(Rect2(c-Vector2(21,21),Vector2(42,42)),[6,8,7][i])
  if game.cooldowns[i]>0:
   draw_circle(c,35,Color(.03,.08,.12,.73))
   text(c+Vector2(0,8),str(ceili(game.cooldowns[i])),25,pale,true)
  text(c+Vector2(0,62),names[i],14,pale,true)
  buttons.append({"rect":Rect2(c-Vector2(42,42),Vector2(84,84)),"id":"skill%d" % i})
 var attack = Vector2(s.x-98,s.y-100)
 draw_circle(attack,66,Color("293d3d"))
 draw_arc(attack,65,0,TAU,64,gold,2)
 draw_arc(attack,58,0,TAU,64,Color("677868"),1)
 icon(Rect2(attack-Vector2(25,37),Vector2(50,50)),0)
 text(attack+Vector2(0,33),"自动攻击" if game.auto_attack else "攻击已停",17,pale,true)
 buttons.append({"rect":Rect2(attack-Vector2(68,68),Vector2(136,136)),"id":"attack"})
 text(Vector2(s.x*.5,s.y-29),"靠近敌人自动攻击  ·  技能可边走边放",14,Color("b6c6b1"),true)
 if game.elapsed<12:
  text(Vector2(s.x*.5,s.y-60),"保护南方水晶；重甲怪和波次奖励可获得木头。",15,pale,true)
 if game.modal!="":
  buttons.clear()
  draw_rect(Rect2(Vector2.ZERO,s),Color(.015,.04,.05,.78))
  draw_modal(s)
 if game.ended!="":
  buttons.clear()
  draw_rect(Rect2(Vector2.ZERO,s),Color(.015,.04,.05,.84))
  panel(Rect2(s.x*.5-300,s.y*.5-180,600,360),true)
  var victory = game.ended=="victory"
  text(Vector2(s.x*.5,s.y*.5-91),"神域仍然屹立" if victory else "防线已被突破",38,pale,true)
  text(Vector2(s.x*.5,s.y*.5-43),"八波怪潮已平息。守卫者，感谢你的坚守。" if victory else "升级技能，补充装备，也可以花金币修复核心。",17,muted,true)
  text(Vector2(s.x*.5,s.y*.5+1),"等级 %d  ·  坚守 %d 波  ·  BOSS 胜场 %d" % [game.level,game.wave_no,game.boss_wins],18,gold,true)
  button(Rect2(s.x*.5-130,s.y*.5+52,260,55),"重新开始","new",true)
 draw_toast(s)

func draw_modal(s: Vector2) -> void:
 var r = Rect2(s.x*.5-420,s.y*.5-240,840,480)
 panel(r,true)
 button(Rect2(r.end.x-68,r.position.y+16,48,36),"×","close")
 match game.modal:
  "shop":
   text(r.position+Vector2(28,44),"军需商店",26,pale)
   text(r.position+Vector2(28,75),"每件装备限购一次，购入即生效。",15,muted)
   for i in range(6):
    var p = r.position+Vector2(28+(i%3)*264,100+int(i/3)*160)
    panel(Rect2(p,Vector2(252,146)))
    icon(Rect2(p+Vector2(14,16),Vector2(38,38)),i)
    text(p+Vector2(62,37),game.ITEMS[i].name,18,pale)
    text(p+Vector2(16,79),game.ITEMS[i].desc,15,muted)
    var owned: bool = game.inventory.has(i)
    button(Rect2(p+Vector2(14,96),Vector2(224,36)),"已装备" if owned else "购买  ·  %d 金币" % game.ITEMS[i].cost,"buy%d" % i,not owned)
  "upgrade":
   text(r.position+Vector2(28,44),"技能升级",26,pale)
   text(r.position+Vector2(28,76),"可用技能点 %d  ·  英雄升级获得技能点  ·  每项最高 5 级" % game.points,15,muted)
   var names = ["旋风斩","雷霆震击","复苏之光"]
   var descriptions = ["近身范围伤害\n半径 145 · 冷却 5 秒","大范围伤害并眩晕\n半径 235 · 冷却 10 秒","立即恢复自身生命\n冷却 16 秒"]
   for i in range(3):
    var p = r.position+Vector2(28+i*264,104)
    panel(Rect2(p,Vector2(252,300)))
    icon(Rect2(p+Vector2(95,20),Vector2(60,60)),[6,8,7][i])
    text(p+Vector2(126,117),names[i],23,pale,true)
    var lines = descriptions[i].split("\n")
    text(p+Vector2(126,157),lines[0],15,muted,true)
    text(p+Vector2(126,184),lines[1],14,muted,true)
    text(p+Vector2(126,220),"当前等级 %d / 5" % game.skills[i],16,gold,true)
    button(Rect2(p+Vector2(16,244),Vector2(220,40)),"升级 · 1 技能点","up%d" % i,true)
  "travel":
   text(r.position+Vector2(28,44),"神域传送阵",26,pale)
   text(r.position+Vector2(28,78),"挑战期间防守战场暂停；胜利或撤离后继续原来的怪潮。",16,muted)
   panel(Rect2(r.position+Vector2(28,110),Vector2(784,150)))
   var boss: Array = art.enemies_hd[12].rect
   draw_texture_rect_region(enemy_atlas,Rect2(r.position+Vector2(36,122),Vector2(110,124)),Rect2(boss[0],boss[1],boss[2],boss[3]))
   text(r.position+Vector2(164,151),"铁角守卫",25,pale)
   text(r.position+Vector2(164,187),"躲开红色预警圈，击败守卫获取奖励。",16,muted)
   text(r.position+Vector2(164,220),"奖励：金币、10 木头、大量经验",15,gold)
   button(Rect2(r.position+Vector2(568,166),Vector2(220,50)),"挑战 · 5 木头","boss",true)
   button(Rect2(r.position+Vector2(28,287),Vector2(372,56)),"修复核心 +400 · 100 金币","repair")
   button(Rect2(r.position+Vector2(420,287),Vector2(392,56)),"撤离挑战区" if game.arena else "返回防守战场","return" if game.arena else "close")
   text(r.position+Vector2(28,393),"已完成挑战 %d 次 · 再次挑战时守卫会变得更强。" % game.boss_wins,17,muted)
  "pause":
   text(r.position+Vector2(28,47),"战场已暂停",28,pale)
   text(r.position+Vector2(28,91),"进度每 20 秒自动保存；切到后台时也会保存并暂停。",17,muted)
   button(Rect2(r.position+Vector2(28,133),Vector2(784,58)),"继续守卫","close",true)
   button(Rect2(r.position+Vector2(28,211),Vector2(380,52)),"保存本地进度","save")
   button(Rect2(r.position+Vector2(430,211),Vector2(382,52)),"声音：开" if game.sound_on else "声音：关","sound")
   text(r.position+Vector2(28,320),"触控：左摇杆移动，右侧释放技能，可同时操作。",17,pale)
   text(r.position+Vector2(28,359),"电脑：WASD 移动 · 1/2/3 技能 · Tab 商店 · Esc 暂停",16,muted)
   text(r.position+Vector2(28,410),"目标：保护核心，完成 8 波防守。",17,gold)

func pointer(pos: Vector2, id: int, pressed: bool) -> void:
 if not pressed:
  if id==joy_id: reset_touch()
  return
 for i in range(buttons.size()-1,-1,-1):
  if buttons[i].rect.has_point(pos):
   game.action(buttons[i].id)
   return
 var s = get_viewport_rect().size
 if game.mode=="playing" and game.modal=="" and game.ended=="" and pos.x<260 and pos.y>s.y-270 and joy_id==-999:
  joy_id = id
  joy_origin = Vector2(125,s.y-118)
  joystick = ((pos-joy_origin)/55).limit_length()

func drag(pos: Vector2, id: int) -> void:
 if id==joy_id: joystick = ((pos-joy_origin)/55).limit_length()

func reset_touch() -> void:
 joy_id = -999
 joystick = Vector2.ZERO

func draw_toast(s: Vector2) -> void:
 if game.toast_time<=0: return
 var width = maxf(360,font.get_string_size(game.toast,HORIZONTAL_ALIGNMENT_LEFT,-1,18).x+48)
 panel(Rect2(s.x*.5-width*.5,151,width,48))
 text(Vector2(s.x*.5,181),game.toast,18,pale,true)

func panel(r: Rect2, accented: bool=false) -> void:
 draw_rect(Rect2(r.position+Vector2(0,5),r.size),Color(0,0,0,.28))
 var points = PackedVector2Array([r.position+Vector2(6,0),r.position+Vector2(r.size.x-6,0),r.position+Vector2(r.size.x,6),r.end-Vector2(0,6),r.end-Vector2(6,0),r.position+Vector2(6,r.size.y),r.position+Vector2(0,r.size.y-6),r.position+Vector2(0,6)])
 var upper = Color("203d3c")
 var lower = Color("102725")
 draw_polygon(points,PackedColorArray([upper,upper,upper,lower,lower,lower,lower,upper]))
 points.append(points[0])
 draw_polyline(points,Color("b49a64") if accented else Color("68806a"),1.2,true)
 draw_line(r.position+Vector2(9,4),r.position+Vector2(r.size.x-9,4),Color(.8,.8,.62,.18),1)
 draw_line(r.position+Vector2(5,r.size.y-4),r.end-Vector2(5,4),Color(0,0,0,.3),1)
 if accented:
  for x in [r.position.x+7,r.end.x-7]:
   var direction = 1 if x<r.get_center().x else -1
   draw_polyline(PackedVector2Array([Vector2(x,r.position.y+22),Vector2(x,r.position.y+8),Vector2(x+14*direction,r.position.y+8)]),gold,1.5,true)
   draw_polyline(PackedVector2Array([Vector2(x,r.end.y-22),Vector2(x,r.end.y-8),Vector2(x+14*direction,r.end.y-8)]),gold,1.5,true)

func button(r: Rect2, label: String, id: String, accented: bool=false) -> void:
 var upper = Color("57766a") if accented else Color("304e46")
 var lower = Color("2b4d43") if accented else Color("1a3730")
 if r.has_point(get_local_mouse_position()):
  upper = upper.lightened(.12)
  lower = lower.lightened(.1)
 draw_rect(Rect2(r.position+Vector2(0,3),r.size),Color(0,0,0,.25))
 draw_polygon(PackedVector2Array([r.position,r.position+Vector2(r.size.x,0),r.end,r.position+Vector2(0,r.size.y)]),PackedColorArray([upper,upper,lower,lower]))
 draw_rect(r,gold if accented else Color("809075"),false,1)
 draw_rect(r.grow(-3),Color(.8,.8,.63,.13),false,1)
 text(r.get_center()+Vector2(0,6),label,17,pale,true)
 buttons.append({"rect":r,"id":id})

func text(pos: Vector2, label: String, size: int=18, color: Color=Color.WHITE, centered: bool=false) -> void:
 var p = pos
 if centered: p.x -= font.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x*.5
 draw_string(font,p+Vector2(0,1),label,HORIZONTAL_ALIGNMENT_LEFT,-1,size,Color(0,0,0,.7))
 draw_string(font,p,label,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func icon(r: Rect2, index: int) -> void:
 var sprite: Array = art.props_hd[[4,5,6,7,8,9,10,12,11][index]].rect
 var source_size = Vector2(sprite[2],sprite[3])
 var size = source_size*minf(r.size.x/source_size.x,r.size.y/source_size.y)
 draw_texture_rect_region(icons,Rect2(r.get_center()-size*.5,size),Rect2(sprite[0],sprite[1],sprite[2],sprite[3]))

func bar(r: Rect2, ratio: float, color: Color) -> void:
 draw_rect(r,Color("203b3e"))
 draw_rect(Rect2(r.position,Vector2(r.size.x*clampf(ratio,0,1),r.size.y)),color)
