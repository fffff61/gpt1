extends Node2D

var game: Node2D
var textures: Dictionary = {}
var layout: Dictionary
var font = preload("res://assets/chinese.otf")
var tree_positions: Array[Vector2] = []
var visible_world = Rect2()

func _ready() -> void:
 texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
 layout = JSON.parse_string(FileAccess.get_file_as_string("res://assets/hd_layout.json"))
 for name in ["hero_hd","enemies_hd","props_hd","terrain_hd"]:
  textures[name] = load("res://assets/%s.png" % name)
 for x in range(160,2100,110):
  for y in [110,1570]: tree_positions.append(Vector2(x,y+(x%5)*8))
 for y in range(250,1510,120):
  for x in [175,2015]: tree_positions.append(Vector2(x+(y%7)*7,y))
 for y in [700,850,1000]:
  for x in [500,1690]: tree_positions.append(Vector2(x,y))

func _draw() -> void:
 visible_world = Rect2(-position/scale,get_viewport_rect().size/scale).grow(180)
 tile_area(Rect2(0,0,2208,1728),0,256)
 var t = game.elapsed
 if game.arena:
  tile_area(Rect2(256,192,1696,1312),2,256)
  tile_area(Rect2(400,320,1408,1024),3,256)
  tile_area(Rect2(976,576,256,256),2,256)
  draw_prop(3,Vector2(1104,770),205)
  draw_string(font,Vector2(1006,540),"铁角守卫 · 挑战祭坛",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color("f1dfb0"))
 else:
  tile_area(Rect2(960,0,288,1728),1,192)
  tile_area(Rect2(544,1120,1152,352),1,192)
  tile_area(Rect2(320,448,1600,128),1,192)
  tile_area(Rect2(976,1216,256,256),2,256)
  for box in game.obstacles.slice(0,4):
   draw_rect(box.grow(5),Color(0.02,0.04,0.04,0.3))
   tile_area(box,3,64)
   draw_rect(box,Color("a2b7a1"),false,2)
   draw_prop(13,Vector2(box.get_center().x,box.position.y+28),45)
   draw_prop(13,Vector2(box.get_center().x,box.end.y+14),45)
  for p in tree_positions: draw_prop(2,p,175)
  draw_prop(1,Vector2(1465,1260),182)
  draw_prop(1,Vector2(685,1260),182)
  draw_prop(3,Vector2(1628,1112),170)
  draw_string(font,Vector2(1426,1062),"军需商店",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("eaddb7"))
  draw_string(font,Vector2(648,1062),"秘法工坊",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("eaddb7"))
  draw_string(font,Vector2(1580,932),"挑战传送阵",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("a8e7d9"))
  var glow = 0.5+sin(t*2)*0.12
  draw_circle(game.CORE_POS-Vector2(0,10),95,Color(0.3,0.8,0.7,0.05+glow*0.04))
  draw_prop(0,game.CORE_POS+Vector2(0,12),194)
  draw_string(font,game.CORE_POS-Vector2(160,80),"神域之心",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("e1d7b3"))
  health_bar(game.CORE_POS-Vector2(160,70),90,game.core_hp/1600.0,Color("7fd6c0"))
  for i in range(7):
   var p = Vector2(940 if i%2==0 else 1266,560+i*90)
   draw_prop(14,p,44)
   draw_circle(p-Vector2(0,25),12+sin(t*4+i)*2,Color(1,.74,.32,.055))
 var actors: Array[Dictionary] = []
 for enemy in game.enemies: actors.append({"hero":false,"pos":enemy.pos,"data":enemy})
 actors.append({"hero":true,"pos":game.hero})
 actors.sort_custom(func(a,b):return a.pos.y<b.pos.y)
 for actor in actors:
  var p: Vector2 = actor.pos
  if actor.hero:
   draw_set_transform(p,0,Vector2(1,.32))
   draw_circle(Vector2.ZERO,24,Color(0.03,.09,.08,.30))
   draw_arc(Vector2.ZERO,27,0,TAU,48,Color("8ed8b5"),2)
   draw_set_transform(Vector2.ZERO)
   var frame = int(t*7)%4 if game.moving else 0
   var tint = Color("ffc8b4") if game.hurt_flash>0 else Color.WHITE
   draw_actor("hero_hd",game.facing*4+frame,p,96,tint)
   if game.attack_flash>0:
    var slash = layout.props_hd[10].rect
    draw_texture_rect_region(textures.props_hd,Rect2(p-Vector2(52,85),Vector2(104,104)),Rect2(slash[0],slash[1],slash[2],slash[3]),Color(1,1,1,game.attack_flash*2.3))
   health_bar(p-Vector2(30,104),60,game.hp/game.max_hp,Color("85d5b9"))
   draw_string_outline(font,p-Vector2(30,110),"守誓者 Lv.%d" % game.level,HORIZONTAL_ALIGNMENT_LEFT,-1,11,2,Color("18372e"))
   draw_string(font,p-Vector2(30,110),"守誓者 Lv.%d" % game.level,HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color("f4ead0"))
  else:
   var e: Dictionary = actor.data
   var frame = int(t*(5 if e.kind==3 else 7)+p.x*0.03)%4
   var tint = Color(1.4,1.25,1.15) if e.hit>0 else Color.WHITE
   var height = [77,83,88,142][e.kind]
   draw_set_transform(p,0,Vector2(1,.3))
   draw_circle(Vector2.ZERO,26 if e.kind==3 else 18,Color(0.02,.035,.04,.27))
   draw_set_transform(Vector2.ZERO)
   draw_actor("enemies_hd",e.kind*4+frame,p,height,tint,e.facing==2)
   health_bar(p-Vector2(48 if e.kind==3 else 24,height+8),96 if e.kind==3 else 48,e.hp/e.max_hp,Color("d58e76"))
   if e.stun>0:
    draw_arc(p-Vector2(0,height+14),9,t*3,t*3+PI*1.5,16,Color("b6e6eb"),1.5)
 for effect in game.effects:
  var progress = 1.0-effect.life/effect.total
  var alpha: float = effect.life/effect.total
  var p: Vector2 = effect.pos
  var r: float = effect.radius
  match effect.kind:
   "warning":
    draw_circle(p,r,Color(0.8,0.24,0.16,0.13+0.09*sin(t*16)))
    draw_arc(p,r,0,TAU,64,Color(0.94,0.42,0.27,0.7),2)
    draw_arc(p,r*progress,0,TAU,48,Color(1,0.6,0.3,0.6),2)
   "slam":
    draw_circle(p,r*(0.5+progress*.5),Color(1,.5,.25,alpha*.2))
    draw_arc(p,r*progress,0,TAU,48,Color(1,.7,.4,alpha),5)
   "cleave":
    var sr = layout.props_hd[10].rect
    draw_set_transform(p,progress*PI*.75)
    draw_texture_rect_region(textures.props_hd,Rect2(-r,-r,r*2,r*2),Rect2(sr[0],sr[1],sr[2],sr[3]),Color(1,1,1,alpha*.65))
    draw_set_transform(Vector2.ZERO)
    draw_arc(p,r*(0.6+progress*0.4),-PI+progress,PI+progress,48,Color(.94,.85,.57,alpha),5)
    draw_arc(p,r*(0.5+progress*.4),-PI+progress,PI+progress,48,Color(.6,.85,.7,alpha*.6),2)
   "storm":
    draw_circle(p,r*progress,Color(.3,.7,.8,alpha*.1))
    draw_arc(p,r*progress,0,TAU,48,Color(.6,.9,.9,alpha),3)
    for k in range(8):
     var q = p+Vector2.from_angle(k*TAU/8+t)*r*(.4+progress*.6)
     draw_polyline(PackedVector2Array([q-Vector2(10,48),q+Vector2(2,-24),q-Vector2(8,24),q+Vector2(7,0)]),Color(.7,.95,.85,alpha),2)
   "heal":
    var sr = layout.props_hd[12].rect
    draw_texture_rect_region(textures.props_hd,Rect2(p-Vector2(r,r*1.35),Vector2(r*2,r*2)),Rect2(sr[0],sr[1],sr[2],sr[3]),Color(1,1,1,alpha*.7))
    draw_arc(p,r*progress,0,TAU,48,Color(.5,.95,.7,alpha),3)
    for k in range(6):
     var q = p+Vector2.from_angle(k*TAU/6+t)*r*.55-Vector2(0,progress*45)
     draw_line(q-Vector2(4,0),q+Vector2(4,0),Color(.7,1,.8,alpha),2)
     draw_line(q-Vector2(0,4),q+Vector2(0,4),Color(.7,1,.8,alpha),2)
   "slash": draw_line(p-Vector2(0,20),effect.end-Vector2(0,18),Color(1,.9,.6,alpha),2)
   "death":
    for k in range(6):
     var q = p+Vector2.from_angle(k*TAU/6)*progress*25
     draw_rect(Rect2(q,Vector2(3,3)),Color(.65,.55,.4,alpha))
 for f in game.floating:
  var c: Color = f.color
  c.a = minf(1,f.life*2)
  draw_string(font,f.pos,f.text,HORIZONTAL_ALIGNMENT_LEFT,-1,14,c)

func draw_actor(atlas: String, index: int, foot: Vector2, height: float, tint: Color=Color.WHITE, mirrored: bool=false) -> void:
 var sprite: Dictionary = layout[atlas][index]
 var r: Array = sprite.rect
 var factor = height/r[3]
 var size = Vector2(r[2],r[3])*factor
 var anchor = Vector2(sprite.anchor[0],sprite.anchor[1])*factor
 var destination = Rect2(foot-anchor,size)
 if mirrored:
  destination.position.x = foot.x+anchor.x
  destination.size.x = -destination.size.x
 draw_texture_rect_region(textures[atlas],destination,Rect2(r[0],r[1],r[2],r[3]),tint)

func draw_prop(index: int, foot: Vector2, height: float) -> void:
 var r: Array = layout.props_hd[index].rect
 var size = Vector2(r[2],r[3])*(height/r[3])
 draw_texture_rect_region(textures.props_hd,Rect2(foot-Vector2(size.x*.5,size.y),size),Rect2(r[0],r[1],r[2],r[3]))

func tile_area(area: Rect2, tile: int, span: int) -> void:
 var atlas: Texture2D = textures.terrain_hd
 var cell = atlas.get_size()/2
 var origin = Vector2(tile%2,int(tile/2))*cell
 for y in range(int(area.position.y),int(area.end.y),span):
  for x in range(int(area.position.x),int(area.end.x),span):
   var size = Vector2(minf(span,area.end.x-x),minf(span,area.end.y-y))
   var destination = Rect2(Vector2(x,y),size)
   if visible_world.intersects(destination):
    draw_texture_rect_region(atlas,destination,Rect2(origin+Vector2.ONE*.5,(cell-Vector2.ONE)*size/span))

func health_bar(pos: Vector2, width: float, ratio: float, color: Color) -> void:
 draw_rect(Rect2(pos-Vector2.ONE,Vector2(width+2,7)),Color("142722"))
 draw_rect(Rect2(pos,Vector2(width,5)),Color("5e4840"))
 draw_rect(Rect2(pos,Vector2(width*clampf(ratio,0,1),5)),color)
 draw_line(pos,pos+Vector2(width*clampf(ratio,0,1),0),Color("d6e5c2"),1)
