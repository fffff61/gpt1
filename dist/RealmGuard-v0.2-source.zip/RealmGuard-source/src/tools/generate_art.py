from PIL import Image, ImageDraw
import random, pathlib, math, shutil, wave, struct
out=pathlib.Path(__file__).resolve().parents[1]/'assets';out.mkdir(exist_ok=True)
rng=random.Random(73)
# Original hand-built pixel sprites. Small palettes, integer coordinates, no resampling.
def knight(kind):
 sheet=Image.new('RGBA',(32*4,48*4))
 for direction in range(4):
  for frame in range(4):
   im=Image.new('RGBA',(32,48));d=ImageDraw.Draw(im)
   bob=[0,-1,0,1][frame];step=[-2,0,2,0][frame]
   ink='#111c29';armor='#6ba5b3';light='#c0d7cb';gold='#d8ad57';dark='#31536c'
   if kind=='orc': armor='#688d42';light='#a4b25d';gold='#b55240';dark='#344d32'
   if kind=='shade': armor='#776ba0';light='#b2a5ce';gold='#bb6873';dark='#413956'
   if kind=='skeleton': armor='#aaac96';light='#e1ddbb';gold='#7a7770';dark='#5f6767'
   # Shadow, boots, moving legs, cloak, shoulder plates, chest and helm.
   d.ellipse((5,39,27,45),fill=(5,12,18,100))
   d.rectangle((10,31+bob,14,39+step),fill=ink);d.rectangle((19,31+bob,23,39-step),fill=ink)
   d.rectangle((9,38+step,15,41+step),fill=dark);d.rectangle((18,38-step,25,41-step),fill=dark)
   d.polygon([(8,17+bob),(23,17+bob),(27,36+bob),(17,39+bob),(6,35+bob)],fill=ink)
   d.polygon([(9,19+bob),(22,19+bob),(24,35+bob),(17,37+bob),(8,34+bob)],fill='#25596a' if kind=='knight' else gold)
   d.rectangle((10,19+bob,22,30+bob),fill=ink);d.rectangle((11,20+bob,21,29+bob),fill=armor)
   d.rectangle((13,21+bob,16,27+bob),fill=light);d.rectangle((10,29+bob,23,32+bob),fill=gold)
   d.rectangle((5,19+bob,11,24+bob),fill=ink);d.rectangle((6,19+bob,10,22+bob),fill=light)
   d.rectangle((21,19+bob,27,25+bob),fill=ink);d.rectangle((22,19+bob,26,22+bob),fill=armor)
   d.rectangle((11,8+bob,22,19+bob),fill=ink);d.rectangle((12,9+bob,21,17+bob),fill=armor)
   d.rectangle((13,8+bob,20,10+bob),fill=light)
   if direction!=3:
    d.rectangle((12 if direction!=2 else 16,13+bob,20 if direction!=1 else 16,15+bob),fill=ink)
    d.point((14 if direction!=2 else 19,14+bob),fill='#8ee9d3' if kind=='knight' else '#f4bc68')
   d.line((17,7+bob,17,3+bob),fill=gold,width=2)
   if kind=='orc':
    d.polygon([(11,11+bob),(7,9+bob),(10,17+bob)],fill=armor);d.polygon([(22,11+bob),(27,9+bob),(23,17+bob)],fill=armor)
   if kind=='shade':
    d.polygon([(10,10+bob),(16,1+bob),(23,11+bob)],fill=dark)
   if direction!=3:
    d.polygon([(4,24+bob),(10,23+bob),(12,29+bob),(8,35+bob),(3,30+bob)],fill=ink)
    d.polygon([(5,25+bob),(9,25+bob),(10,29+bob),(8,33+bob),(4,30+bob)],fill=gold)
    d.line((7,26+bob,7,31+bob),fill=light)
   # Blade angles change across walking frames.
   sx=26; sy=29+bob
   d.line((sx-2,sy+2,sx+3,sy-3),fill=gold,width=2)
   d.line((sx+1,sy-2,30,13+bob+(frame%2)*2),fill=ink,width=4)
   d.line((sx+1,sy-3,29,13+bob+(frame%2)*2),fill=light,width=2)
   sheet.alpha_composite(im,(frame*32,direction*48))
 sheet.save(out/f'{kind}.png')
for k in ['knight','orc','shade','skeleton']:knight(k)
# Boss, animated iron horn guardian.
s=Image.new('RGBA',(64*4,80))
for f in range(4):
 im=Image.new('RGBA',(64,80));d=ImageDraw.Draw(im);b=[0,-1,0,1][f]
 d.ellipse((5,62,60,78),fill=(0,0,0,100))
 for x,off in [(17,2 if f==1 else 0),(41,-2 if f==3 else 0)]:
  d.rectangle((x,51+b,x+9,71+off),fill='#20232d');d.rectangle((x-2,67+off,x+12,73+off),fill='#59606b')
 d.polygon([(14,29+b),(49,29+b),(54,57+b),(36,64+b),(12,57+b)],fill='#171d2b')
 d.rectangle((18,31+b,46,54+b),fill='#7b4755');d.polygon([(22,33+b),(31,38+b),(40,32+b),(43,49+b),(30,55+b),(20,48+b)],fill='#a96764')
 d.rectangle((9,28+b,23,37+b),fill='#bd9d66');d.rectangle((43,27+b,57,38+b),fill='#bd9d66')
 d.rectangle((23,12+b,43,32+b),fill='#171d2b');d.rectangle((25,14+b,41,29+b),fill='#73787b')
 d.rectangle((27,21+b,31,23+b),fill='#ffba76');d.rectangle((36,21+b,40,23+b),fill='#ffba76')
 d.polygon([(25,17+b),(15,13+b),(13,3+b),(19,10+b),(27,11+b)],fill='#d9cba1');d.polygon([(41,17+b),(51,12+b),(54,3+b),(47,9+b),(40,11+b)],fill='#d9cba1')
 d.line((53,37+b,56,66+b),fill='#705348',width=4);d.polygon([(47,45+b),(63,35+b),(63,56+b),(48,55+b)],fill='#383f52');d.line((61,37+b,61,54+b),fill='#b7c6c7',width=2)
 s.alpha_composite(im,(64*f,0))
s.save(out/'boss.png')
# Ground tiles: patterned grass, worn flagstones, wall and water.
tiles=Image.new('RGBA',(32*8,32))
for t in range(8):
 im=Image.new('RGBA',(32,32),'#25483c');d=ImageDraw.Draw(im)
 if t<3:
  d.rectangle((0,0,31,31),fill=['#284c3b','#2c503e','#244636'][t])
  for _ in range(45):
   x,y=rng.randrange(32),rng.randrange(32);c=rng.choice(['#365a41','#1e3d32','#3b6248'])
   d.line((x,y,x+1,y-2),fill=c)
  if t==2:
   for x,y in [(8,9),(22,24)]:d.point((x,y),fill='#b6a66b');d.point((x+1,y-1),fill='#7a9360')
 elif t in [3,4]:
  d.rectangle((0,0,31,31),fill='#3e4b43')
  for x,y,w,h in [(1,1,15,13),(18,1,13,13),(1,16,10,15),(13,16,18,15)]:
   d.rectangle((x,y,x+w-1,y+h-1),fill=rng.choice(['#778072','#828572','#6d786b','#8b8c76']))
   d.line((x,y,x+w-1,y),fill='#a2a38a');d.line((x+w-1,y,x+w-1,y+h-1),fill='#59665b')
   for _ in range(9):
    px,py=rng.randrange(x,x+w),rng.randrange(y,y+h);d.point((px,py),fill='#91927d')
  if t==4:d.line((0,28,7,21,12,23,17,16),fill='#385542',width=2)
 elif t==5:
  d.rectangle((0,0,31,31),fill='#253a3d')
  for y in [1,13,25]:
   for x in [-8,9,26] if y==13 else [0,17]:
    d.rectangle((x,y,x+15,y+10),fill='#738079');d.line((x,y,x+15,y),fill='#a2ad92');d.line((x,y+10,x+15,y+10),fill='#465b52')
 elif t==6:
  d.rectangle((0,0,31,31),fill='#213f50')
  for _ in range(12):
   x,y=rng.randrange(28),rng.randrange(32);d.line((x,y,x+4,y),fill='#376474')
 else:
  d.rectangle((0,0,31,31),fill='#485d51');d.rectangle((2,2,29,29),outline='#8f9775');d.rectangle((5,5,26,26),outline='#263f37')
 tiles.alpha_composite(im,(t*32,0))
tiles.save(out/'tiles.png')
# Tree silhouettes layered in three shades.
im=Image.new('RGBA',(64,80));d=ImageDraw.Draw(im)
d.ellipse((7,57,58,78),fill=(5,15,15,90));d.rectangle((28,43,36,69),fill='#494037');d.rectangle((31,44,34,67),fill='#76634b')
for x,y,w,h in [(29,1,6,27),(21,11,24,24),(14,25,39,22),(7,40,52,22)]:
 d.polygon([(x+w//2,y),(x+w,y+h),(x,y+h)],fill='#142e29');d.polygon([(x+w//2,y+2),(x+w-5,y+h-3),(x+3,y+h-3)],fill='#28523d');d.line((x+w//2,y+5,x+6,y+h-5),fill='#46704c',width=2)
im.save(out/'tree.png')
# Trading hall.
im=Image.new('RGBA',(112,112));d=ImageDraw.Draw(im)
d.ellipse((4,87,108,109),fill=(5,13,18,100));d.rectangle((21,47,94,95),fill='#253237');d.rectangle((25,50,91,92),fill='#98927a')
for y in range(54,91,10):d.line((25,y,91,y),fill='#747866')
d.rectangle((47,64,65,95),fill='#263733');d.rectangle((51,68,61,94),fill='#456653')
for x in [30,75]:d.rectangle((x,60,x+10,74),fill='#243740');d.line((x+5,60,x+5,74),fill='#b9a579')
d.polygon([(10,49),(56,13),(104,49),(95,57),(18,57)],fill='#182731')
d.polygon([(15,48),(56,17),(98,48),(92,52),(22,52)],fill='#496b7b')
for y in [29,38,47]:d.line((56-(y-17)*1.3,y,56+(y-17)*1.3,y),fill='#6d8d94',width=2)
d.line((56,14,56,48),fill='#b5ad7d',width=2);d.rectangle((87,66,106,81),fill='#392f27');d.rectangle((89,68,104,79),outline='#d2ad65');d.line((93,73,101,73),fill='#e6cc83',width=2)
im.save(out/'shop.png')
# Sacred core and altar.
im=Image.new('RGBA',(96,112));d=ImageDraw.Draw(im)
d.ellipse((3,75,93,109),fill=(0,0,0,100));d.polygon([(8,78),(47,59),(88,78),(88,92),(47,109),(8,93)],fill='#293e42')
d.polygon([(10,77),(47,60),(86,77),(47,95)],fill='#7f8a7c');d.polygon([(20,77),(47,65),(76,77),(47,90)],outline='#c7b57c')
for x,y in [(20,63),(68,64),(15,80),(73,81)]:d.rectangle((x,y,x+7,y+10),fill='#7c897e');d.rectangle((x+1,y,x+6,y+3),fill='#d7c189')
d.polygon([(48,8),(64,39),(58,64),(48,77),(33,52),(35,30)],fill='#142f3c');d.polygon([(48,12),(60,39),(54,61),(48,70),(37,49),(39,30)],fill='#55bcae');d.polygon([(48,13),(47,45),(38,49),(40,30)],fill='#b2ead1');d.polygon([(48,45),(60,39),(54,60),(48,70)],fill='#2d7e8b')
im.save(out/'core.png')
im=Image.new('RGBA',(96,96));d=ImageDraw.Draw(im)
d.ellipse((6,24,90,87),fill='#243a3e',outline='#697c72',width=3);d.ellipse((14,30,82,79),outline='#c2a56a',width=2);d.ellipse((23,36,73,73),outline='#54b8a8',width=2)
for a in range(0,360,45):
 x=48+int(math.cos(math.radians(a))*29);y=54+int(math.sin(math.radians(a))*21);d.rectangle((x-2,y-2,x+2,y+2),fill='#a1d3ba')
d.polygon([(48,40),(61,54),(48,68),(35,54)],outline='#d7b978')
im.save(out/'altar.png')
# Item icons, all original pixels.
icons=Image.new('RGBA',(32*9,32))
for i in range(9):
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im)
 if i in [0,6]:
  d.line((8,25,24,7),fill='#1a252d',width=7);d.line((9,24,24,7),fill='#bdcfcd',width=4);d.line((11,21,24,7),fill='#eef0cd',width=1);d.line((5,20,13,28),fill='#d6ad58',width=3)
 elif i==1:
  d.polygon([(7,6),(25,6),(24,21),(16,28),(8,21)],fill='#c9aa61');d.polygon([(10,9),(22,9),(21,20),(16,24),(11,20)],fill='#5c8393');d.line((16,11,16,22),fill='#d4d8b7',width=2)
 elif i==2:
  d.polygon([(8,14),(15,9),(23,14),(24,25),(16,28),(7,24)],fill='#b55855');d.rectangle((12,4,19,10),fill='#d0b477');d.rectangle((12,11,18,16),fill='#ec9d81')
 elif i==3:
  d.polygon([(9,6),(21,6),(20,22),(26,24),(25,28),(10,28)],fill='#8d7060');d.line((10,9,20,9),fill='#d8b679',width=3);d.rectangle((12,11,16,23),fill='#ad9170')
 elif i==4:
  d.ellipse((7,6,25,27),outline='#d8bd6e',width=4);d.polygon([(16,3),(23,10),(16,17),(9,10)],fill='#6bc3b8');d.line((15,7,13,10),fill='#d7ebcc',width=2)
 elif i==5:
  d.polygon([(7,5),(15,8),(25,5),(25,26),(16,29),(7,25)],fill='#5d507a');d.line((16,9,16,25),fill='#c5ab70',width=2);d.line((19,12,23,11),fill='#d3c3a1');d.line((19,16,23,15),fill='#d3c3a1')
 elif i==7:
  for a in range(0,360,45):
   x=16+int(math.cos(math.radians(a))*10);y=16+int(math.sin(math.radians(a))*10);d.line((16,16,x,y),fill='#e3bc6e',width=3)
  d.ellipse((10,10,22,22),fill='#f1db9a')
 else:
  d.polygon([(18,3),(7,18),(15,18),(11,29),(26,12),(18,13)],fill='#8be0cf');d.line((17,7,11,16),fill='#e1f3d0',width=2)
 icons.alpha_composite(im,(i*32,0))
icons.save(out/'icons.png')
# Full static world textures use native-resolution tiles.
for arena in [False,True]:
 world=Image.new('RGBA',(2208,1728));d=ImageDraw.Draw(world)
 for y in range(54):
  for x in range(69):
   road=(30<=x<=38) or (y in range(35,46) and x in range(17,53)) or (y in range(14,18) and x in range(10,60))
   t=rng.randrange(3) if not road else rng.choice([3,3,3,4])
   if arena: t=3 if (x<9 or x>59 or y<7 or y>45) else rng.randrange(3)
   world.alpha_composite(tiles.crop((t*32,0,t*32+32,32)),(x*32,y*32))
 d=ImageDraw.Draw(world)
 if not arena:
  for x in [736,1440]:
   for ya,yb in [(224,416),(576,928)]:
    for y in range(ya,yb,32):
     world.alpha_composite(tiles.crop((160,0,192,32)),(x,y));world.alpha_composite(tiles.crop((160,0,192,32)),(x+32,y))
    d.rectangle((x-3,ya-6,x+66,ya+7),fill='#a5ac90');d.rectangle((x-3,yb-7,x+66,yb+5),fill='#a5ac90')
 else:
  for x in range(256,1952,32):
   for y in [192,1472]:world.alpha_composite(tiles.crop((160,0,192,32)),(x,y))
  for y in range(192,1504,32):
   for x in [256,1920]:world.alpha_composite(tiles.crop((160,0,192,32)),(x,y))
 world.convert('RGB').save(out/('arena.png' if arena else 'world.png'))
# Application icon.
im=Image.new('RGB',(128,128),'#122c32');core=Image.open(out/'core.png');im.paste(core,(16,3),core);d=ImageDraw.Draw(im);d.rectangle((3,3,124,124),outline='#b99b61',width=3);im.save(out/'icon.png')
# Compact synthesized offline audio.
for name,freq,duration in [('hit',160,.09),('skill',420,.32),('coin',880,.12),('warn',110,.35)]:
 rate=22050; data=[]
 for j in range(int(rate*duration)):
  t=j/rate;env=(1-t/duration)**2
  tone=math.sin(2*math.pi*(freq*t+(160*t*t if name=='skill' else 0)))
  if name=='hit':tone=.6*tone+.4*rng.uniform(-1,1)
  data.append(int(tone*env*6500))
 with wave.open(str(out/f'{name}.wav'),'wb') as w:
  w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes(struct.pack('<'+'h'*len(data),*data))
from fontTools import subset
from fontTools.ttLib import TTFont
font=TTFont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',fontNumber=2)
options=subset.Options(); options.name_IDs=['*']; options.name_legacy=True; options.name_languages=['*']
subsetter=subset.Subsetter(options=options)
text=''.join(f.read_text() for f in out.parent.glob('*.gd'))+''.join(chr(n) for n in range(32,127))
subsetter.populate(text=text); subsetter.subset(font); font.save(out/'chinese.otf')
print('Generated original pixel assets, world maps and audio')
