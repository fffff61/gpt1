#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p builds
godot --headless --editor --import --quit
godot --headless --export-debug Android builds/RealmGuard-v0.1-android.apk
