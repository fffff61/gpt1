# 神域守卫 · 像素防线（网页版）

手机横屏触控和电脑均可玩的单人像素防守游戏。Godot 4.6.3，GDScript，WebGL 2，单线程 WebAssembly，无服务器游戏逻辑。

玩法：保护南方神域之心，抵御八波怪潮；自动攻击、三个主动技能、英雄成长、六格装备、独立 BOSS 挑战和本地进度。原始参考只有约 94 秒录像，未展示的完整数值与规则为本版设计。

手机横屏后用左摇杆移动，右侧按钮释放技能；可同时移动与施法。右下大按钮切换自动攻击。右侧菜单购买装备、升级技能、修复核心和挑战 BOSS。

电脑：WASD 移动、1/2/3 技能、空格切换自动攻击、Tab 商店、Esc 暂停、F5 保存。

首次联网加载约 19 MB。页面提示缓存完成后，可在相同浏览器离线重新打开。浏览器须支持 WebGL 2、WebAssembly、DecompressionStream 与 Service Worker，推荐新版 Chrome。浏览器本地存档与该浏览器和站点绑定；清除站点数据会清除存档。游戏本身无需账号服务；托管站点的访问范围按 Sites 的私有设置保持。

## 源码与构建

- `src/`：完整 Godot 工程；`src/AGENTS.md` 保留用户编程规则。
- `dist/`：可直接静态部署的游戏。
- `tools/build_web.sh`：用 Godot 导出后整理 Web 产物。
- `tools/prepare_web.py`：压缩 WASM、在引擎下载入口接入标准 gzip 解压、生成中文加载页与离线缓存配置。

安装 Godot 4.6.3 与对应 Web Export Templates 后，在本目录执行 `tools/build_web.sh`。运行时无需 Node 服务或后端数据库。

完整功能检查：

```sh
godot --headless --path src --editor --import --quit
godot --headless --path src --script res://tests/verify.gd
godot --headless --path src --script res://tests/touch_restart.gd
```

代码约定：外部存档在读取入口一次校验；内部不重复判空、不滥用 try/catch；只为实际复用、引擎回调或清晰职责边界抽函数。额外的低概率防御功能需先获得用户同意。

像素角色、建筑、地块、图标和音效由工程中的素材程序生成；中文字体按其附带许可使用。当前内容为 1 名英雄、3 种普通怪物、3 个技能、6 件装备、8 波防守和 1 种可重复挑战 BOSS。

## v0.2 精绘美术更新

主角改为参考图方向的白衣青绿剑修，使用 16 帧四向行走图集；普通敌人与 BOSS 使用精绘行走图集。建筑、玉石祭坛、松树、装备、技能图标及地面统一替换为高细节国风素材，采用线性采样和逐帧落脚点对齐。

新增素材原图保存在 `src/assets/*_hd.png`；`hd_layout.json` 记录裁切矩形与角色落脚锚点，原图保持完整。素材由图像生成工具按用户参考图制作；`tools/map_hd_atlases.py` 仅分析透明通道生成区域元数据。原型阶段的素材生成脚本仍保留，但不会重建这些新版精绘素材。
