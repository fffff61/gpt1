from pathlib import Path
from PIL import Image
import numpy as np,json,shutil
root=Path(__file__).resolve().parents[1]/'src/assets'
# Only inspect alpha coverage and record texture regions; the original images remain intact.
def region(im,box):
 a=np.array(im.getchannel('A'))[box[1]:box[3],box[0]:box[2]]
 ys,xs=np.where(a>90)
 x0,x1=int(xs.min()),int(xs.max())+1;y0,y1=int(ys.min()),int(ys.max())+1
 feet=a[max(y0,y1-max(8,int((y1-y0)*.10))):y1,x0:x1].astype(float).sum(axis=0)
 anchor=float(np.dot(np.arange(x1-x0),feet)/feet.sum())
 return {'rect':[box[0]+x0,box[1]+y0,x1-x0,y1-y0],'anchor':[anchor,float(y1-y0)]}
layout={}
for name,rows,xs in [('hero_hd',[0,320,625,934,1254],[0,380,660,950,1254]),('enemies_hd',[0,313,625,942,1254],[0,350,660,970,1254])]:
 im=Image.open(root/(name+'.png'));layout[name]=[]
 for y0,y1 in zip(rows,rows[1:]):
  for x0,x1 in zip(xs,xs[1:]):layout[name].append(region(im,(x0,y0,x1,y1)))
props=[(0,0,270,365),(270,0,628,365),(628,0,967,373),(967,0,1254,373),
(0,366,315,676),(315,366,630,676),(630,374,943,676),(943,374,1254,676),
(0,676,315,950),(315,676,630,950),(630,676,944,950),(944,676,1254,950),
(0,950,337,1254),(337,955,686,1254),(686,950,924,1254),(924,950,1254,1254)]
im=Image.open(root/'props_hd.png');layout['props_hd']=[region(im,b) for b in props]
(root/'hd_layout.json').write_text(json.dumps(layout,separators=(',',':')))
print('Recorded',sum(len(x) for x in layout.values()),'sprite regions without altering the generated atlas pixels.')
