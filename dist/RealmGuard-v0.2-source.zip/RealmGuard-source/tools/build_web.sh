#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
godot --headless --path src --export-release Web "$PWD/dist/index.html"
python3 tools/prepare_web.py
